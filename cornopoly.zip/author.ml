let aaron_hours_worked = 10
let michelle_hours_worked = 10
let amy_hours_worked = 15
let meghana_hours_worked = 10