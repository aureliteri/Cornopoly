let aaron_hours_worked = 40
let michelle_hours_worked = 40
let amy_hours_worked = 40
let meghana_hours_worked = 40